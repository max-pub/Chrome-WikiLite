var tmp = document.getElementById('content');
tmp.removeAttribute('class');








// var tmp = document.getElementById('mw-panel');
// tmp.parentNode.removeChild(tmp);

// var tmp = document.getElementById('mw-navigation');
// tmp.parentNode.removeChild(tmp);

// var tmp = document.getElementById('mw-page-base');
// tmp.parentNode.removeChild(tmp);

// var tmp = document.getElementById('mw-head-base');
// tmp.parentNode.removeChild(tmp);

// var tmp = document.getElementsByClassName('Vorlage_Belege_fehlen')[0];
// tmp.parentNode.removeChild(tmp);

// var tmp = document.getElementById('footer');
// tmp.parentNode.removeChild(tmp);

